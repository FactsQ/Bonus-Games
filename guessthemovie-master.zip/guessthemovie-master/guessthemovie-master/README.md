Guess The Movie
=================================

![Guess The Movie](http://codenatic.com/wp-content/uploads/2016/01/guessthemovie.jpg "Awesome Movie Game!")

A funny game where the objective is guess the movie using an image.

I have made this Movie game just for fun, i'm pretty sure that the logic can be improved a lot but...

SETUP
=====

If you want to mount your own game you will need an API-KEY from **TMDB**, you can ask for one in their forums, then just update the game.js file and assign your API-KEY to the **this.key** variable at the beginning of the file.
  
Usage
=====

Click on the letters to create the correct title, if you have a mistake, click on the title letter to undo it!

On Line Version
=============

You can check a live version [here](http://codenatic.com/projects/guessthemovie/)

Licence
=======

The MIT License (MIT)

Copyright (c) 2015 Franco Cavestri

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
